﻿//A8977
//Program 4
//CIS 199-01
//December 4th, 2018 @ 11:59pm
//Program for using methods and properties in relation to library books
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
	class LibraryBook
	{
		private string _title; //Title of the book
		private string _author;//author of the book
		private string _publisher;//Publisher of the book
		private int _copyYear;//the copyright year of the book
		private string _callNumber;// the book's call number 
		private bool checkedOut;//Boolean for determining whether or not the book was checked out
		public LibraryBook(string title, string author, string publisher, int copyrightYear
			, string callNumber) //five-parameter constructor
		{//turning parameters into their properties
			Title = title;
			Author = author;
			Publisher = publisher;
			Copyright = copyrightYear;
			Call = callNumber;
		}
		public string Title//Property for title
		{//Precondition: Enter in the title 
			get
			{
				return _title;
			}
			//PostCondition: Return the title
			//Precondition: All titles are valid
			set
			{
				_title = value;
			}
			//PostCondition: Validate all titles
		}
		public string Author// Property for author 
		{
			//Precondition: Get the author's name
			get
			{
				return _author;
			}
			//Postcondition: Return author's name
			//Precondition: All names are valid
			set
			{
				_author = value;
			}
			//Postcondition: Validate all names
		}
		public string Publisher//Property for publisher 
		{
			//Precondition: Get the name of the Publisher
			get
			{
				return _publisher;
			}
			//Postcondition: Returns the name of the publisher 
			//Precondition:Validate the name of all publishers
			set
			{
				_publisher = value;
			}
			//Postcondition: Validates the name of all publishers
		}
		public int Copyright
		{
			//Precondition: Get the year of the copyright
			get
			{
				return _copyYear;
			}
			//Postcondition: Return the year of the copyright 
			//Precondition: Make sure the year is a valid integer greater than zero and the property returns 2018 if the integer is invalid
			set
			{
				if (value >= 0)
					_copyYear = value;
				else
					_copyYear = 2018;
			}
			//Postcondition: Returns valid year if greater than zero and 2018 if a non-valid integer
		}
		public string Call
		{
			//Precondition: Get the library's book call number
			get
			{
				return _callNumber;
			}
			//Postcondition: Return the call number
			//Precondition: Validate all library call numbers
			set
			{
				_callNumber = value;

			}
			//Postcondition: All library call numbers are validated
		}
		public void CheckOut()//Method for checking out a library book
		{
			checkedOut = true;//Library book checked out
		}
		public void ReturnToShelf()//Method for returning a library book
		{
			checkedOut = false;//Library book returned to library
		}
		public bool IsCheckedOut()//Method for returning whether a book has been checked out or returned 
		{
			return checkedOut;//Is the book checked out boolean
		}

		public override string ToString()//Overriden method for creating a formatted string
		{
			return $"Title: {Title}  {Environment.NewLine}" +
			$"Author: {Author}  {Environment.NewLine}" +
			 $"Publisher: {Publisher}  { Environment.NewLine}" +
			 $"Copyright Year: {Copyright}  {Environment.NewLine}" +
			 $"Call Number: {Call}  {Environment.NewLine}" +
			 $"Checkout Status: {checkedOut} {Environment.NewLine}";
		}
	}
}
