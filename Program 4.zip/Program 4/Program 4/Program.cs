﻿//A8977
//Program 4
//CIS 199-01
//December 4th, 2018 @ 11:59pm
//Program for using methods and properties in relation to library books
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
	class Program
	{
		static void Main(string[] args)
		{
			//List of objects for the array
			LibraryBook book1 =
				new LibraryBook("Fire and Ice", "Erin Harper", "Collins", 2003, "54");
			LibraryBook book2 =
				new LibraryBook("Into the Wild", "Erin Harper", "Collins", 2002, "53");
			LibraryBook book3 =
				new LibraryBook("Dusk", "Erin Harper", "Collins", 2006, "65");
			LibraryBook book4 =
				new LibraryBook("The Lightning Thief", "Rick Riordan", "Hyperion", 2008, "74");
			LibraryBook book5 =
				new LibraryBook("The Last Olympian", "Rick Riordan", "Hyperion", 2012, "89");
			//Placing the books into an array named books
			LibraryBook[] books = { book1, book2, book3, book4, book5 };

			// Using method sBook to print out the orignal 
			Console.WriteLine($"Books in library...{Environment.NewLine}");
			sBook(books);

			// changing either the book's publisher or call number or checking out the book
			book1.Publisher = "McGraw-Hill";
			book2.CheckOut();
			book3.Call = "69";
			book4.CheckOut();
			book5.CheckOut();

			// Again, using a method, printing out each object's new data to the console.
			Console.WriteLine($"New update for books...{Environment.NewLine}");
			sBook(books);

			// Calling the appropriate method to return each book that was checked out.
			book1.ReturnToShelf();
			book2.ReturnToShelf();
			book3.ReturnToShelf();
			book4.ReturnToShelf();
			book5.ReturnToShelf();

			// Finally, printing each book's data to the console one last time.
			Console.WriteLine($"Finally, all books are returned to the library...{Environment.NewLine}");
			sBook(books);

			Console.ReadKey();
		}

		// sBook Method
		public static void sBook(LibraryBook[] books)
		{
			for (int i = 0; i < books.Length; i++)
			{
				Console.WriteLine("Book #" + (i + 1));// Printing out the book along with all of its information
				Console.WriteLine(books[i]);
			}
		}
	} 



}
	
	

